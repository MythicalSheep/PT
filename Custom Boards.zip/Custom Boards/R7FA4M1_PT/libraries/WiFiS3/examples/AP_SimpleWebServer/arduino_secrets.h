// Both SSID and password must be 8 characters or longer
#define SECRET_SSID "testAP"
#define SECRET_PASS "123456789"
